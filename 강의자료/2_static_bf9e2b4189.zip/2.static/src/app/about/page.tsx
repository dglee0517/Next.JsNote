export default function AboutPage() {
  return <h1>About Us!</h1>;
}
