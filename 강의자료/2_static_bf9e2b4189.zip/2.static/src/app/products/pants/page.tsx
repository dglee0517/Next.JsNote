export default function PantsPage() {
  return <h1>바지 제품 설명 페이지</h1>;
}
