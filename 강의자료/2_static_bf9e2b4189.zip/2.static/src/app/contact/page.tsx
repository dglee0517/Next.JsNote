export default function ContactPage() {
  return <h1>Contact Us!</h1>;
}
